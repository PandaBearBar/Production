package com.jb.project3.finalCouponSystem.bins.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public enum Category {
    Food,
    Electricity,
    Restaurant,
    Vacation;
}
